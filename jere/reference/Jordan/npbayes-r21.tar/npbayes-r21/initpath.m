tic
base = [pwd '/'];
addpath([base 'utilities']);
addpath([base 'distributions/multinomial']);
addpath([base 'hdpmix']);
addpath([base 'barsdemo']);


