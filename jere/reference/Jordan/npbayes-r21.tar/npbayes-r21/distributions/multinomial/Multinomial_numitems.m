function ii = Multinomial_numitems(hh,qq);

ii = sum(qq,1);
