function qq = newclass(hh);

qq = zeros(size(hh));
