function qq = Multinomial_delitem(hh,qq,ss);

qq(ss) = qq(ss) - 1;
