function qq = Multinomial_additem(hh,qq,ss);

qq(ss) = qq(ss) + 1;


