function hdp = qq_delitems(hdp,cc,ss);

hdp.base.classqq = feval(hdp.func.delitems,hdp.base.hh,hdp.base.classqq,cc,ss);
