function hdp = qq_additems(hdp,cc,ss);

hdp.base.classqq = feval(hdp.func.additems,hdp.base.hh,hdp.base.classqq,cc,ss);
